
CREATE INDEX IX_Team_TeamName ON Team (teamName);