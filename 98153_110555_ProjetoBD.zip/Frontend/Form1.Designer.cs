﻿namespace NBAproject
{
    partial class game_list_admin
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.DefRebHome = new System.Windows.Forms.TextBox();
            this.teams = new System.Windows.Forms.ListBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtWL = new System.Windows.Forms.TextBox();
            this.txtConference = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.games_list = new System.Windows.Forms.ListBox();
            this.Games = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCoach = new System.Windows.Forms.TextBox();
            this.txtDivision = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.squad_list = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.statistics_players = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Viewer = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.DeleteCoach = new System.Windows.Forms.Button();
            this.EditCoach = new System.Windows.Forms.Button();
            this.AddCoach = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.CoachAge = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.CoachId = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.PlayerId = new System.Windows.Forms.TextBox();
            this.PlayerWeight = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.PlayerHeight = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.PlayerPosition = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.PlayerAge = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.PlayerName = new System.Windows.Forms.TextBox();
            this.Delete = new System.Windows.Forms.Button();
            this.Edit = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.CoachEdit = new System.Windows.Forms.TextBox();
            this.Coach = new System.Windows.Forms.Label();
            this.player_list = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Search = new System.Windows.Forms.Button();
            this.SearchTeam = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.TovHome = new System.Windows.Forms.TextBox();
            this.FoulsHome = new System.Windows.Forms.TextBox();
            this.BlocksHome = new System.Windows.Forms.TextBox();
            this.StealsHome = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.AssistsHome = new System.Windows.Forms.TextBox();
            this.OffRebHome = new System.Windows.Forms.TextBox();
            this.FtaHome = new System.Windows.Forms.TextBox();
            this.FtmHome = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.ThreeptaHome = new System.Windows.Forms.TextBox();
            this.ThreeptmHome = new System.Windows.Forms.TextBox();
            this.FgaHome = new System.Windows.Forms.TextBox();
            this.FgmHome = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.AwayTeamPoints = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.HomeTeamPoints = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.AwayTeamName = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.HomeTeamName = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.GameDate = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.SearchGamesByTeam = new System.Windows.Forms.Button();
            this.searchTeamAdmin = new System.Windows.Forms.TextBox();
            this.gamesListAdmin = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.GameId = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.edit_statistics_home = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.FgmAway = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.TovAway = new System.Windows.Forms.TextBox();
            this.a = new System.Windows.Forms.Label();
            this.FgaAway = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.BlocksAway = new System.Windows.Forms.TextBox();
            this.aaa = new System.Windows.Forms.Label();
            this.aa = new System.Windows.Forms.Label();
            this.ThreeptmAway = new System.Windows.Forms.TextBox();
            this.StealsAway = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.AssistsAway = new System.Windows.Forms.TextBox();
            this.aaaaa = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.DefRebAway = new System.Windows.Forms.TextBox();
            this.FoulsAway = new System.Windows.Forms.TextBox();
            this.ThreeptaAway = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.OffRebAway = new System.Windows.Forms.TextBox();
            this.FtmAway = new System.Windows.Forms.TextBox();
            this.FtaAway = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.squadAdmin = new System.Windows.Forms.ListBox();
            this.FgmPlayer = new System.Windows.Forms.TextBox();
            this.BlocksPlayer = new System.Windows.Forms.TextBox();
            this.FtaPlayer = new System.Windows.Forms.TextBox();
            this.FtmPlayer = new System.Windows.Forms.TextBox();
            this.StealsPlayer = new System.Windows.Forms.TextBox();
            this.FoulsPlayer = new System.Windows.Forms.TextBox();
            this.AssistsPlayer = new System.Windows.Forms.TextBox();
            this.DefRebPlayer = new System.Windows.Forms.TextBox();
            this.OffRebPlayer = new System.Windows.Forms.TextBox();
            this.ThreeptaPlayer = new System.Windows.Forms.TextBox();
            this.ThreeptmPlayer = new System.Windows.Forms.TextBox();
            this.FgaPlayer = new System.Windows.Forms.TextBox();
            this.TovPlayer = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label44 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.PlayerIdAdmin = new System.Windows.Forms.TextBox();
            this.Id = new System.Windows.Forms.Label();
            this.Sponsor = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.Viewer.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // DefRebHome
            // 
            this.DefRebHome.Location = new System.Drawing.Point(126, 170);
            this.DefRebHome.Name = "DefRebHome";
            this.DefRebHome.Size = new System.Drawing.Size(100, 20);
            this.DefRebHome.TabIndex = 77;
            // 
            // teams
            // 
            this.teams.FormattingEnabled = true;
            this.teams.Location = new System.Drawing.Point(6, 68);
            this.teams.Name = "teams";
            this.teams.Size = new System.Drawing.Size(284, 329);
            this.teams.TabIndex = 0;
            this.teams.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(299, 84);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 2;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(299, 144);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(100, 20);
            this.txtCity.TabIndex = 3;
            this.txtCity.TextChanged += new System.EventHandler(this.txtCity_TextChanged);
            // 
            // txtWL
            // 
            this.txtWL.Location = new System.Drawing.Point(511, 84);
            this.txtWL.Name = "txtWL";
            this.txtWL.Size = new System.Drawing.Size(100, 20);
            this.txtWL.TabIndex = 4;
            this.txtWL.TextChanged += new System.EventHandler(this.txtWL_TextChanged);
            // 
            // txtConference
            // 
            this.txtConference.Location = new System.Drawing.Point(405, 144);
            this.txtConference.Name = "txtConference";
            this.txtConference.Size = new System.Drawing.Size(100, 20);
            this.txtConference.TabIndex = 5;
            this.txtConference.TextChanged += new System.EventHandler(this.txtDivisionId_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(402, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Conference";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(296, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Team";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(296, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "City";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(508, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Record";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Teams";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 406);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Conference";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(9, 422);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 16;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged_1);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(146, 422);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 17;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(143, 406);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Division";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // games_list
            // 
            this.games_list.FormattingEnabled = true;
            this.games_list.Location = new System.Drawing.Point(296, 198);
            this.games_list.Name = "games_list";
            this.games_list.Size = new System.Drawing.Size(313, 199);
            this.games_list.TabIndex = 19;
            this.games_list.SelectedIndexChanged += new System.EventHandler(this.games_list_SelectedIndexChanged);
            // 
            // Games
            // 
            this.Games.AutoSize = true;
            this.Games.Location = new System.Drawing.Point(296, 182);
            this.Games.Name = "Games";
            this.Games.Size = new System.Drawing.Size(40, 13);
            this.Games.TabIndex = 20;
            this.Games.Text = "Games";
            this.Games.Click += new System.EventHandler(this.Games_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(402, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Coach";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txtCoach
            // 
            this.txtCoach.Location = new System.Drawing.Point(405, 84);
            this.txtCoach.Name = "txtCoach";
            this.txtCoach.Size = new System.Drawing.Size(100, 20);
            this.txtCoach.TabIndex = 22;
            this.txtCoach.TextChanged += new System.EventHandler(this.txtCoach_TextChanged);
            // 
            // txtDivision
            // 
            this.txtDivision.Location = new System.Drawing.Point(511, 144);
            this.txtDivision.Name = "txtDivision";
            this.txtDivision.Size = new System.Drawing.Size(100, 20);
            this.txtDivision.TabIndex = 23;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(508, 130);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "Division";
            // 
            // squad_list
            // 
            this.squad_list.FormattingEnabled = true;
            this.squad_list.Location = new System.Drawing.Point(617, 68);
            this.squad_list.Name = "squad_list";
            this.squad_list.Size = new System.Drawing.Size(347, 329);
            this.squad_list.TabIndex = 25;
            this.squad_list.SelectedIndexChanged += new System.EventHandler(this.squad_list_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(614, 52);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 13);
            this.label11.TabIndex = 26;
            this.label11.Text = "Squad";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(617, 422);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 27;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(614, 406);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 13);
            this.label12.TabIndex = 28;
            this.label12.Text = "Year";
            // 
            // statistics_players
            // 
            this.statistics_players.Location = new System.Drawing.Point(984, 68);
            this.statistics_players.Name = "statistics_players";
            this.statistics_players.Size = new System.Drawing.Size(258, 329);
            this.statistics_players.TabIndex = 29;
            this.statistics_players.Text = "";
            this.statistics_players.TextChanged += new System.EventHandler(this.statistics_players_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(981, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 13);
            this.label7.TabIndex = 30;
            this.label7.Text = "Individual Statistics";
            this.label7.Click += new System.EventHandler(this.label7_Click_1);
            // 
            // Viewer
            // 
            this.Viewer.Controls.Add(this.tabPage1);
            this.Viewer.Controls.Add(this.tabPage2);
            this.Viewer.Controls.Add(this.tabPage3);
            this.Viewer.Location = new System.Drawing.Point(0, 42);
            this.Viewer.Name = "Viewer";
            this.Viewer.SelectedIndex = 0;
            this.Viewer.Size = new System.Drawing.Size(1273, 487);
            this.Viewer.TabIndex = 31;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label64);
            this.tabPage1.Controls.Add(this.Sponsor);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.comboBox3);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.teams);
            this.tabPage1.Controls.Add(this.statistics_players);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.comboBox2);
            this.tabPage1.Controls.Add(this.squad_list);
            this.tabPage1.Controls.Add(this.txtName);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtDivision);
            this.tabPage1.Controls.Add(this.txtCity);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txtWL);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtCoach);
            this.tabPage1.Controls.Add(this.txtConference);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.Games);
            this.tabPage1.Controls.Add(this.games_list);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1265, 461);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Viewer";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.DeleteCoach);
            this.tabPage2.Controls.Add(this.EditCoach);
            this.tabPage2.Controls.Add(this.AddCoach);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.CoachAge);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.CoachId);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.PlayerId);
            this.tabPage2.Controls.Add(this.PlayerWeight);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.PlayerHeight);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.PlayerPosition);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.PlayerAge);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.PlayerName);
            this.tabPage2.Controls.Add(this.Delete);
            this.tabPage2.Controls.Add(this.Edit);
            this.tabPage2.Controls.Add(this.Add);
            this.tabPage2.Controls.Add(this.CoachEdit);
            this.tabPage2.Controls.Add(this.Coach);
            this.tabPage2.Controls.Add(this.player_list);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.Search);
            this.tabPage2.Controls.Add(this.SearchTeam);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1265, 461);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "TeamManaging";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // DeleteCoach
            // 
            this.DeleteCoach.Location = new System.Drawing.Point(827, 222);
            this.DeleteCoach.Name = "DeleteCoach";
            this.DeleteCoach.Size = new System.Drawing.Size(75, 23);
            this.DeleteCoach.TabIndex = 58;
            this.DeleteCoach.Text = "DeleteCoach";
            this.DeleteCoach.UseVisualStyleBackColor = true;
            this.DeleteCoach.Click += new System.EventHandler(this.button3_Click);
            // 
            // EditCoach
            // 
            this.EditCoach.Location = new System.Drawing.Point(746, 222);
            this.EditCoach.Name = "EditCoach";
            this.EditCoach.Size = new System.Drawing.Size(75, 23);
            this.EditCoach.TabIndex = 57;
            this.EditCoach.Text = "EditCoach";
            this.EditCoach.UseVisualStyleBackColor = true;
            this.EditCoach.Click += new System.EventHandler(this.button2_Click);
            // 
            // AddCoach
            // 
            this.AddCoach.Location = new System.Drawing.Point(665, 222);
            this.AddCoach.Name = "AddCoach";
            this.AddCoach.Size = new System.Drawing.Size(75, 23);
            this.AddCoach.TabIndex = 56;
            this.AddCoach.Text = "AddCoach";
            this.AddCoach.UseVisualStyleBackColor = true;
            this.AddCoach.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(729, 157);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(57, 13);
            this.label21.TabIndex = 55;
            this.label21.Text = "CoachAge";
            // 
            // CoachAge
            // 
            this.CoachAge.Location = new System.Drawing.Point(732, 173);
            this.CoachAge.Name = "CoachAge";
            this.CoachAge.Size = new System.Drawing.Size(100, 20);
            this.CoachAge.TabIndex = 54;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(729, 108);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 13);
            this.label20.TabIndex = 53;
            this.label20.Text = "CoachId";
            // 
            // CoachId
            // 
            this.CoachId.Location = new System.Drawing.Point(732, 124);
            this.CoachId.Name = "CoachId";
            this.CoachId.Size = new System.Drawing.Size(100, 20);
            this.CoachId.TabIndex = 52;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(462, 55);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(50, 13);
            this.label19.TabIndex = 51;
            this.label19.Text = "Player ID";
            // 
            // PlayerId
            // 
            this.PlayerId.Location = new System.Drawing.Point(465, 78);
            this.PlayerId.Name = "PlayerId";
            this.PlayerId.Size = new System.Drawing.Size(100, 20);
            this.PlayerId.TabIndex = 50;
            // 
            // PlayerWeight
            // 
            this.PlayerWeight.Location = new System.Drawing.Point(465, 326);
            this.PlayerWeight.Name = "PlayerWeight";
            this.PlayerWeight.Size = new System.Drawing.Size(100, 20);
            this.PlayerWeight.TabIndex = 49;
            this.PlayerWeight.TextChanged += new System.EventHandler(this.PlayerWeight_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(462, 310);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(73, 13);
            this.label18.TabIndex = 48;
            this.label18.Text = "Player Weight";
            // 
            // PlayerHeight
            // 
            this.PlayerHeight.Location = new System.Drawing.Point(465, 278);
            this.PlayerHeight.Name = "PlayerHeight";
            this.PlayerHeight.Size = new System.Drawing.Size(100, 20);
            this.PlayerHeight.TabIndex = 47;
            this.PlayerHeight.TextChanged += new System.EventHandler(this.PlayerHeight_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(462, 262);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 13);
            this.label17.TabIndex = 46;
            this.label17.Text = "Player Height";
            // 
            // PlayerPosition
            // 
            this.PlayerPosition.Location = new System.Drawing.Point(463, 225);
            this.PlayerPosition.Name = "PlayerPosition";
            this.PlayerPosition.Size = new System.Drawing.Size(100, 20);
            this.PlayerPosition.TabIndex = 45;
            this.PlayerPosition.TextChanged += new System.EventHandler(this.PlayerPosition_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(460, 209);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 13);
            this.label16.TabIndex = 44;
            this.label16.Text = "Player Position";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(460, 157);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(58, 13);
            this.label15.TabIndex = 43;
            this.label15.Text = "Player Age";
            // 
            // PlayerAge
            // 
            this.PlayerAge.Location = new System.Drawing.Point(463, 173);
            this.PlayerAge.Name = "PlayerAge";
            this.PlayerAge.Size = new System.Drawing.Size(100, 20);
            this.PlayerAge.TabIndex = 42;
            this.PlayerAge.TextChanged += new System.EventHandler(this.PlayerAge_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(460, 108);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 13);
            this.label14.TabIndex = 41;
            this.label14.Text = "Player Name";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // PlayerName
            // 
            this.PlayerName.Location = new System.Drawing.Point(463, 124);
            this.PlayerName.Name = "PlayerName";
            this.PlayerName.Size = new System.Drawing.Size(100, 20);
            this.PlayerName.TabIndex = 40;
            this.PlayerName.TextChanged += new System.EventHandler(this.PlayerName_TextChanged);
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(647, 378);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(75, 23);
            this.Delete.TabIndex = 39;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Edit
            // 
            this.Edit.Location = new System.Drawing.Point(554, 378);
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(75, 23);
            this.Edit.TabIndex = 38;
            this.Edit.Text = "Edit";
            this.Edit.UseVisualStyleBackColor = true;
            this.Edit.Click += new System.EventHandler(this.Edit_Click);
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(463, 378);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(75, 23);
            this.Add.TabIndex = 37;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // CoachEdit
            // 
            this.CoachEdit.Location = new System.Drawing.Point(732, 71);
            this.CoachEdit.Name = "CoachEdit";
            this.CoachEdit.Size = new System.Drawing.Size(100, 20);
            this.CoachEdit.TabIndex = 36;
            this.CoachEdit.TextChanged += new System.EventHandler(this.CoachEdit_TextChanged);
            // 
            // Coach
            // 
            this.Coach.AutoSize = true;
            this.Coach.Location = new System.Drawing.Point(729, 55);
            this.Coach.Name = "Coach";
            this.Coach.Size = new System.Drawing.Size(38, 13);
            this.Coach.TabIndex = 35;
            this.Coach.Text = "Coach";
            this.Coach.Click += new System.EventHandler(this.Coach_Click);
            // 
            // player_list
            // 
            this.player_list.FormattingEnabled = true;
            this.player_list.Location = new System.Drawing.Point(94, 81);
            this.player_list.Name = "player_list";
            this.player_list.Size = new System.Drawing.Size(347, 329);
            this.player_list.TabIndex = 34;
            this.player_list.SelectedIndexChanged += new System.EventHandler(this.player_list_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(551, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 13);
            this.label13.TabIndex = 33;
            this.label13.Text = "Insert your team name";
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(570, 45);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(75, 23);
            this.Search.TabIndex = 32;
            this.Search.Text = "Search";
            this.Search.UseVisualStyleBackColor = true;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // SearchTeam
            // 
            this.SearchTeam.Location = new System.Drawing.Point(554, 19);
            this.SearchTeam.Name = "SearchTeam";
            this.SearchTeam.Size = new System.Drawing.Size(100, 20);
            this.SearchTeam.TabIndex = 3;
            this.SearchTeam.TextChanged += new System.EventHandler(this.SearchTeam_TextChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label30);
            this.tabPage3.Controls.Add(this.GameId);
            this.tabPage3.Controls.Add(this.tabControl1);
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.AwayTeamPoints);
            this.tabPage3.Controls.Add(this.label27);
            this.tabPage3.Controls.Add(this.HomeTeamPoints);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.AwayTeamName);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.HomeTeamName);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.GameDate);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.SearchGamesByTeam);
            this.tabPage3.Controls.Add(this.searchTeamAdmin);
            this.tabPage3.Controls.Add(this.gamesListAdmin);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1265, 461);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Admin";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(243, 54);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(39, 13);
            this.label41.TabIndex = 91;
            this.label41.Text = "Blocks";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(243, 102);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(26, 13);
            this.label40.TabIndex = 90;
            this.label40.Text = "Tov";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(6, 154);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(32, 13);
            this.label39.TabIndex = 89;
            this.label39.Text = "Fouls";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(243, 6);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(36, 13);
            this.label38.TabIndex = 88;
            this.label38.Text = "Steals";
            // 
            // TovHome
            // 
            this.TovHome.Location = new System.Drawing.Point(246, 118);
            this.TovHome.Name = "TovHome";
            this.TovHome.Size = new System.Drawing.Size(100, 20);
            this.TovHome.TabIndex = 87;
            // 
            // FoulsHome
            // 
            this.FoulsHome.Location = new System.Drawing.Point(3, 170);
            this.FoulsHome.Name = "FoulsHome";
            this.FoulsHome.Size = new System.Drawing.Size(100, 20);
            this.FoulsHome.TabIndex = 86;
            // 
            // BlocksHome
            // 
            this.BlocksHome.Location = new System.Drawing.Point(246, 70);
            this.BlocksHome.Name = "BlocksHome";
            this.BlocksHome.Size = new System.Drawing.Size(100, 20);
            this.BlocksHome.TabIndex = 85;
            // 
            // StealsHome
            // 
            this.StealsHome.Location = new System.Drawing.Point(246, 22);
            this.StealsHome.Name = "StealsHome";
            this.StealsHome.Size = new System.Drawing.Size(100, 20);
            this.StealsHome.TabIndex = 84;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(123, 6);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(24, 13);
            this.label37.TabIndex = 83;
            this.label37.Text = "Ftm";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(125, 54);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(22, 13);
            this.label36.TabIndex = 82;
            this.label36.Text = "Fta";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(123, 102);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 13);
            this.label35.TabIndex = 81;
            this.label35.Text = "OffReb";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(125, 154);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(44, 13);
            this.label34.TabIndex = 80;
            this.label34.Text = "DefReb";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(125, 204);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(39, 13);
            this.label33.TabIndex = 79;
            this.label33.Text = "Assists";
            // 
            // AssistsHome
            // 
            this.AssistsHome.Location = new System.Drawing.Point(128, 220);
            this.AssistsHome.Name = "AssistsHome";
            this.AssistsHome.Size = new System.Drawing.Size(100, 20);
            this.AssistsHome.TabIndex = 78;
            // 
            // OffRebHome
            // 
            this.OffRebHome.Location = new System.Drawing.Point(128, 118);
            this.OffRebHome.Name = "OffRebHome";
            this.OffRebHome.Size = new System.Drawing.Size(100, 20);
            this.OffRebHome.TabIndex = 76;
            // 
            // FtaHome
            // 
            this.FtaHome.Location = new System.Drawing.Point(126, 70);
            this.FtaHome.Name = "FtaHome";
            this.FtaHome.Size = new System.Drawing.Size(100, 20);
            this.FtaHome.TabIndex = 75;
            // 
            // FtmHome
            // 
            this.FtmHome.Location = new System.Drawing.Point(126, 22);
            this.FtmHome.Name = "FtmHome";
            this.FtmHome.Size = new System.Drawing.Size(100, 20);
            this.FtmHome.TabIndex = 74;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(6, 54);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(25, 13);
            this.label32.TabIndex = 73;
            this.label32.Text = "Fga";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 102);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(52, 13);
            this.label31.TabIndex = 72;
            this.label31.Text = "Threeptm";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(3, 204);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(50, 13);
            this.label29.TabIndex = 70;
            this.label29.Text = "Threepta";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(3, 6);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(27, 13);
            this.label28.TabIndex = 69;
            this.label28.Text = "Fgm";
            // 
            // ThreeptaHome
            // 
            this.ThreeptaHome.Location = new System.Drawing.Point(3, 220);
            this.ThreeptaHome.Name = "ThreeptaHome";
            this.ThreeptaHome.Size = new System.Drawing.Size(100, 20);
            this.ThreeptaHome.TabIndex = 68;
            // 
            // ThreeptmHome
            // 
            this.ThreeptmHome.Location = new System.Drawing.Point(3, 118);
            this.ThreeptmHome.Name = "ThreeptmHome";
            this.ThreeptmHome.Size = new System.Drawing.Size(100, 20);
            this.ThreeptmHome.TabIndex = 66;
            // 
            // FgaHome
            // 
            this.FgaHome.Location = new System.Drawing.Point(3, 70);
            this.FgaHome.Name = "FgaHome";
            this.FgaHome.Size = new System.Drawing.Size(100, 20);
            this.FgaHome.TabIndex = 65;
            // 
            // FgmHome
            // 
            this.FgmHome.Location = new System.Drawing.Point(3, 22);
            this.FgmHome.Name = "FgmHome";
            this.FgmHome.Size = new System.Drawing.Size(100, 20);
            this.FgmHome.TabIndex = 64;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(530, 355);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 63;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(449, 355);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 62;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(368, 355);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 61;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // AwayTeamPoints
            // 
            this.AwayTeamPoints.Location = new System.Drawing.Point(368, 308);
            this.AwayTeamPoints.Name = "AwayTeamPoints";
            this.AwayTeamPoints.Size = new System.Drawing.Size(100, 20);
            this.AwayTeamPoints.TabIndex = 60;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(365, 292);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(62, 13);
            this.label27.TabIndex = 59;
            this.label27.Text = "AwayPoints";
            // 
            // HomeTeamPoints
            // 
            this.HomeTeamPoints.Location = new System.Drawing.Point(368, 256);
            this.HomeTeamPoints.Name = "HomeTeamPoints";
            this.HomeTeamPoints.Size = new System.Drawing.Size(100, 20);
            this.HomeTeamPoints.TabIndex = 58;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(365, 240);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(64, 13);
            this.label26.TabIndex = 57;
            this.label26.Text = "HomePoints";
            // 
            // AwayTeamName
            // 
            this.AwayTeamName.Location = new System.Drawing.Point(368, 208);
            this.AwayTeamName.Name = "AwayTeamName";
            this.AwayTeamName.Size = new System.Drawing.Size(100, 20);
            this.AwayTeamName.TabIndex = 56;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(365, 192);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 13);
            this.label25.TabIndex = 55;
            this.label25.Text = "AwayTeam";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(365, 144);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(62, 13);
            this.label24.TabIndex = 54;
            this.label24.Text = "HomeTeam";
            // 
            // HomeTeamName
            // 
            this.HomeTeamName.Location = new System.Drawing.Point(368, 160);
            this.HomeTeamName.Name = "HomeTeamName";
            this.HomeTeamName.Size = new System.Drawing.Size(100, 20);
            this.HomeTeamName.TabIndex = 53;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(365, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(30, 13);
            this.label23.TabIndex = 52;
            this.label23.Text = "Date";
            // 
            // GameDate
            // 
            this.GameDate.Location = new System.Drawing.Point(368, 116);
            this.GameDate.Name = "GameDate";
            this.GameDate.Size = new System.Drawing.Size(100, 20);
            this.GameDate.TabIndex = 51;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(8, 57);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(111, 13);
            this.label22.TabIndex = 38;
            this.label22.Text = "Insert your team name";
            // 
            // SearchGamesByTeam
            // 
            this.SearchGamesByTeam.Location = new System.Drawing.Point(114, 73);
            this.SearchGamesByTeam.Name = "SearchGamesByTeam";
            this.SearchGamesByTeam.Size = new System.Drawing.Size(75, 23);
            this.SearchGamesByTeam.TabIndex = 37;
            this.SearchGamesByTeam.Text = "Search";
            this.SearchGamesByTeam.UseVisualStyleBackColor = true;
            this.SearchGamesByTeam.Click += new System.EventHandler(this.SearchGamesByTeam_Click);
            // 
            // searchTeamAdmin
            // 
            this.searchTeamAdmin.Location = new System.Drawing.Point(8, 73);
            this.searchTeamAdmin.Name = "searchTeamAdmin";
            this.searchTeamAdmin.Size = new System.Drawing.Size(100, 20);
            this.searchTeamAdmin.TabIndex = 36;
            // 
            // gamesListAdmin
            // 
            this.gamesListAdmin.FormattingEnabled = true;
            this.gamesListAdmin.Location = new System.Drawing.Point(6, 99);
            this.gamesListAdmin.Name = "gamesListAdmin";
            this.gamesListAdmin.Size = new System.Drawing.Size(347, 329);
            this.gamesListAdmin.TabIndex = 35;
            this.gamesListAdmin.SelectedIndexChanged += new System.EventHandler(this.g_SelectedIndexChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(733, 57);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(489, 385);
            this.tabControl1.TabIndex = 92;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.edit_statistics_home);
            this.tabPage4.Controls.Add(this.FgmHome);
            this.tabPage4.Controls.Add(this.label40);
            this.tabPage4.Controls.Add(this.label41);
            this.tabPage4.Controls.Add(this.TovHome);
            this.tabPage4.Controls.Add(this.label28);
            this.tabPage4.Controls.Add(this.FgaHome);
            this.tabPage4.Controls.Add(this.label38);
            this.tabPage4.Controls.Add(this.BlocksHome);
            this.tabPage4.Controls.Add(this.label39);
            this.tabPage4.Controls.Add(this.label32);
            this.tabPage4.Controls.Add(this.ThreeptmHome);
            this.tabPage4.Controls.Add(this.StealsHome);
            this.tabPage4.Controls.Add(this.label31);
            this.tabPage4.Controls.Add(this.label33);
            this.tabPage4.Controls.Add(this.label34);
            this.tabPage4.Controls.Add(this.AssistsHome);
            this.tabPage4.Controls.Add(this.label35);
            this.tabPage4.Controls.Add(this.label36);
            this.tabPage4.Controls.Add(this.label37);
            this.tabPage4.Controls.Add(this.DefRebHome);
            this.tabPage4.Controls.Add(this.FoulsHome);
            this.tabPage4.Controls.Add(this.ThreeptaHome);
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.Controls.Add(this.OffRebHome);
            this.tabPage4.Controls.Add(this.FtmHome);
            this.tabPage4.Controls.Add(this.FtaHome);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(481, 320);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "HomeTeam";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button8);
            this.tabPage5.Controls.Add(this.FgmAway);
            this.tabPage5.Controls.Add(this.label42);
            this.tabPage5.Controls.Add(this.label43);
            this.tabPage5.Controls.Add(this.TovAway);
            this.tabPage5.Controls.Add(this.a);
            this.tabPage5.Controls.Add(this.FgaAway);
            this.tabPage5.Controls.Add(this.label45);
            this.tabPage5.Controls.Add(this.BlocksAway);
            this.tabPage5.Controls.Add(this.aaa);
            this.tabPage5.Controls.Add(this.aa);
            this.tabPage5.Controls.Add(this.ThreeptmAway);
            this.tabPage5.Controls.Add(this.StealsAway);
            this.tabPage5.Controls.Add(this.label48);
            this.tabPage5.Controls.Add(this.label49);
            this.tabPage5.Controls.Add(this.label50);
            this.tabPage5.Controls.Add(this.AssistsAway);
            this.tabPage5.Controls.Add(this.aaaaa);
            this.tabPage5.Controls.Add(this.label52);
            this.tabPage5.Controls.Add(this.label53);
            this.tabPage5.Controls.Add(this.DefRebAway);
            this.tabPage5.Controls.Add(this.FoulsAway);
            this.tabPage5.Controls.Add(this.ThreeptaAway);
            this.tabPage5.Controls.Add(this.label54);
            this.tabPage5.Controls.Add(this.OffRebAway);
            this.tabPage5.Controls.Add(this.FtmAway);
            this.tabPage5.Controls.Add(this.FtaAway);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(481, 320);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "AwayTeam";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // GameId
            // 
            this.GameId.Location = new System.Drawing.Point(368, 73);
            this.GameId.Name = "GameId";
            this.GameId.Size = new System.Drawing.Size(100, 20);
            this.GameId.TabIndex = 93;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(365, 57);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(16, 13);
            this.label30.TabIndex = 94;
            this.label30.Text = "Id";
            // 
            // edit_statistics_home
            // 
            this.edit_statistics_home.Location = new System.Drawing.Point(9, 276);
            this.edit_statistics_home.Name = "edit_statistics_home";
            this.edit_statistics_home.Size = new System.Drawing.Size(75, 23);
            this.edit_statistics_home.TabIndex = 95;
            this.edit_statistics_home.Text = "Edit";
            this.edit_statistics_home.UseVisualStyleBackColor = true;
            this.edit_statistics_home.Click += new System.EventHandler(this.edit_statistics_home_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(26, 276);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 123;
            this.button8.Text = "Edit";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // FgmAway
            // 
            this.FgmAway.Location = new System.Drawing.Point(23, 31);
            this.FgmAway.Name = "FgmAway";
            this.FgmAway.Size = new System.Drawing.Size(100, 20);
            this.FgmAway.TabIndex = 96;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(263, 111);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(26, 13);
            this.label42.TabIndex = 120;
            this.label42.Text = "Tov";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(263, 63);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(39, 13);
            this.label43.TabIndex = 121;
            this.label43.Text = "Blocks";
            // 
            // TovAway
            // 
            this.TovAway.Location = new System.Drawing.Point(266, 127);
            this.TovAway.Name = "TovAway";
            this.TovAway.Size = new System.Drawing.Size(100, 20);
            this.TovAway.TabIndex = 117;
            // 
            // a
            // 
            this.a.AutoSize = true;
            this.a.Location = new System.Drawing.Point(23, 15);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(27, 13);
            this.a.TabIndex = 100;
            this.a.Text = "Fgm";
            // 
            // FgaAway
            // 
            this.FgaAway.Location = new System.Drawing.Point(23, 79);
            this.FgaAway.Name = "FgaAway";
            this.FgaAway.Size = new System.Drawing.Size(100, 20);
            this.FgaAway.TabIndex = 97;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(263, 15);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(36, 13);
            this.label45.TabIndex = 118;
            this.label45.Text = "Steals";
            // 
            // BlocksAway
            // 
            this.BlocksAway.Location = new System.Drawing.Point(266, 79);
            this.BlocksAway.Name = "BlocksAway";
            this.BlocksAway.Size = new System.Drawing.Size(100, 20);
            this.BlocksAway.TabIndex = 115;
            // 
            // aaa
            // 
            this.aaa.AutoSize = true;
            this.aaa.Location = new System.Drawing.Point(26, 163);
            this.aaa.Name = "aaa";
            this.aaa.Size = new System.Drawing.Size(32, 13);
            this.aaa.TabIndex = 119;
            this.aaa.Text = "Fouls";
            // 
            // aa
            // 
            this.aa.AutoSize = true;
            this.aa.Location = new System.Drawing.Point(26, 63);
            this.aa.Name = "aa";
            this.aa.Size = new System.Drawing.Size(25, 13);
            this.aa.TabIndex = 103;
            this.aa.Text = "Fga";
            // 
            // ThreeptmAway
            // 
            this.ThreeptmAway.Location = new System.Drawing.Point(23, 127);
            this.ThreeptmAway.Name = "ThreeptmAway";
            this.ThreeptmAway.Size = new System.Drawing.Size(100, 20);
            this.ThreeptmAway.TabIndex = 98;
            // 
            // StealsAway
            // 
            this.StealsAway.Location = new System.Drawing.Point(266, 31);
            this.StealsAway.Name = "StealsAway";
            this.StealsAway.Size = new System.Drawing.Size(100, 20);
            this.StealsAway.TabIndex = 114;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(26, 111);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(52, 13);
            this.label48.TabIndex = 102;
            this.label48.Text = "Threeptm";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(145, 213);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(39, 13);
            this.label49.TabIndex = 109;
            this.label49.Text = "Assists";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(145, 163);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(44, 13);
            this.label50.TabIndex = 110;
            this.label50.Text = "DefReb";
            // 
            // AssistsAway
            // 
            this.AssistsAway.Location = new System.Drawing.Point(148, 229);
            this.AssistsAway.Name = "AssistsAway";
            this.AssistsAway.Size = new System.Drawing.Size(100, 20);
            this.AssistsAway.TabIndex = 108;
            // 
            // aaaaa
            // 
            this.aaaaa.AutoSize = true;
            this.aaaaa.Location = new System.Drawing.Point(143, 111);
            this.aaaaa.Name = "aaaaa";
            this.aaaaa.Size = new System.Drawing.Size(41, 13);
            this.aaaaa.TabIndex = 111;
            this.aaaaa.Text = "OffReb";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(145, 63);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(22, 13);
            this.label52.TabIndex = 112;
            this.label52.Text = "Fta";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(143, 15);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(24, 13);
            this.label53.TabIndex = 113;
            this.label53.Text = "Ftm";
            // 
            // DefRebAway
            // 
            this.DefRebAway.Location = new System.Drawing.Point(146, 179);
            this.DefRebAway.Name = "DefRebAway";
            this.DefRebAway.Size = new System.Drawing.Size(100, 20);
            this.DefRebAway.TabIndex = 107;
            // 
            // FoulsAway
            // 
            this.FoulsAway.Location = new System.Drawing.Point(23, 179);
            this.FoulsAway.Name = "FoulsAway";
            this.FoulsAway.Size = new System.Drawing.Size(100, 20);
            this.FoulsAway.TabIndex = 116;
            // 
            // ThreeptaAway
            // 
            this.ThreeptaAway.Location = new System.Drawing.Point(23, 229);
            this.ThreeptaAway.Name = "ThreeptaAway";
            this.ThreeptaAway.Size = new System.Drawing.Size(100, 20);
            this.ThreeptaAway.TabIndex = 99;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(23, 213);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(50, 13);
            this.label54.TabIndex = 101;
            this.label54.Text = "Threepta";
            // 
            // OffRebAway
            // 
            this.OffRebAway.Location = new System.Drawing.Point(148, 127);
            this.OffRebAway.Name = "OffRebAway";
            this.OffRebAway.Size = new System.Drawing.Size(100, 20);
            this.OffRebAway.TabIndex = 106;
            // 
            // FtmAway
            // 
            this.FtmAway.Location = new System.Drawing.Point(146, 31);
            this.FtmAway.Name = "FtmAway";
            this.FtmAway.Size = new System.Drawing.Size(100, 20);
            this.FtmAway.TabIndex = 104;
            // 
            // FtaAway
            // 
            this.FtaAway.Location = new System.Drawing.Point(146, 79);
            this.FtaAway.Name = "FtaAway";
            this.FtaAway.Size = new System.Drawing.Size(100, 20);
            this.FtaAway.TabIndex = 105;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.Id);
            this.tabPage6.Controls.Add(this.PlayerIdAdmin);
            this.tabPage6.Controls.Add(this.label63);
            this.tabPage6.Controls.Add(this.label62);
            this.tabPage6.Controls.Add(this.label61);
            this.tabPage6.Controls.Add(this.label60);
            this.tabPage6.Controls.Add(this.label59);
            this.tabPage6.Controls.Add(this.label58);
            this.tabPage6.Controls.Add(this.label57);
            this.tabPage6.Controls.Add(this.label56);
            this.tabPage6.Controls.Add(this.label55);
            this.tabPage6.Controls.Add(this.label51);
            this.tabPage6.Controls.Add(this.label47);
            this.tabPage6.Controls.Add(this.label46);
            this.tabPage6.Controls.Add(this.label44);
            this.tabPage6.Controls.Add(this.button4);
            this.tabPage6.Controls.Add(this.TovPlayer);
            this.tabPage6.Controls.Add(this.FgaPlayer);
            this.tabPage6.Controls.Add(this.ThreeptmPlayer);
            this.tabPage6.Controls.Add(this.ThreeptaPlayer);
            this.tabPage6.Controls.Add(this.OffRebPlayer);
            this.tabPage6.Controls.Add(this.DefRebPlayer);
            this.tabPage6.Controls.Add(this.AssistsPlayer);
            this.tabPage6.Controls.Add(this.FoulsPlayer);
            this.tabPage6.Controls.Add(this.StealsPlayer);
            this.tabPage6.Controls.Add(this.FtmPlayer);
            this.tabPage6.Controls.Add(this.FtaPlayer);
            this.tabPage6.Controls.Add(this.BlocksPlayer);
            this.tabPage6.Controls.Add(this.FgmPlayer);
            this.tabPage6.Controls.Add(this.squadAdmin);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(481, 359);
            this.tabPage6.TabIndex = 2;
            this.tabPage6.Text = "PlayerStatistics";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // squadAdmin
            // 
            this.squadAdmin.FormattingEnabled = true;
            this.squadAdmin.Location = new System.Drawing.Point(3, 3);
            this.squadAdmin.Name = "squadAdmin";
            this.squadAdmin.Size = new System.Drawing.Size(247, 316);
            this.squadAdmin.TabIndex = 35;
            this.squadAdmin.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged_1);
            // 
            // FgmPlayer
            // 
            this.FgmPlayer.Location = new System.Drawing.Point(256, 21);
            this.FgmPlayer.Name = "FgmPlayer";
            this.FgmPlayer.Size = new System.Drawing.Size(100, 20);
            this.FgmPlayer.TabIndex = 105;
            // 
            // BlocksPlayer
            // 
            this.BlocksPlayer.Location = new System.Drawing.Point(362, 248);
            this.BlocksPlayer.Name = "BlocksPlayer";
            this.BlocksPlayer.Size = new System.Drawing.Size(100, 20);
            this.BlocksPlayer.TabIndex = 108;
            this.BlocksPlayer.TextChanged += new System.EventHandler(this.BlocksPlayer_TextChanged);
            // 
            // FtaPlayer
            // 
            this.FtaPlayer.Location = new System.Drawing.Point(256, 248);
            this.FtaPlayer.Name = "FtaPlayer";
            this.FtaPlayer.Size = new System.Drawing.Size(100, 20);
            this.FtaPlayer.TabIndex = 109;
            // 
            // FtmPlayer
            // 
            this.FtmPlayer.Location = new System.Drawing.Point(256, 206);
            this.FtmPlayer.Name = "FtmPlayer";
            this.FtmPlayer.Size = new System.Drawing.Size(100, 20);
            this.FtmPlayer.TabIndex = 110;
            // 
            // StealsPlayer
            // 
            this.StealsPlayer.Location = new System.Drawing.Point(362, 206);
            this.StealsPlayer.Name = "StealsPlayer";
            this.StealsPlayer.Size = new System.Drawing.Size(100, 20);
            this.StealsPlayer.TabIndex = 111;
            // 
            // FoulsPlayer
            // 
            this.FoulsPlayer.Location = new System.Drawing.Point(362, 156);
            this.FoulsPlayer.Name = "FoulsPlayer";
            this.FoulsPlayer.Size = new System.Drawing.Size(100, 20);
            this.FoulsPlayer.TabIndex = 112;
            // 
            // AssistsPlayer
            // 
            this.AssistsPlayer.Location = new System.Drawing.Point(362, 110);
            this.AssistsPlayer.Name = "AssistsPlayer";
            this.AssistsPlayer.Size = new System.Drawing.Size(100, 20);
            this.AssistsPlayer.TabIndex = 113;
            // 
            // DefRebPlayer
            // 
            this.DefRebPlayer.Location = new System.Drawing.Point(362, 62);
            this.DefRebPlayer.Name = "DefRebPlayer";
            this.DefRebPlayer.Size = new System.Drawing.Size(100, 20);
            this.DefRebPlayer.TabIndex = 114;
            // 
            // OffRebPlayer
            // 
            this.OffRebPlayer.Location = new System.Drawing.Point(362, 21);
            this.OffRebPlayer.Name = "OffRebPlayer";
            this.OffRebPlayer.Size = new System.Drawing.Size(100, 20);
            this.OffRebPlayer.TabIndex = 115;
            // 
            // ThreeptaPlayer
            // 
            this.ThreeptaPlayer.Location = new System.Drawing.Point(256, 156);
            this.ThreeptaPlayer.Name = "ThreeptaPlayer";
            this.ThreeptaPlayer.Size = new System.Drawing.Size(100, 20);
            this.ThreeptaPlayer.TabIndex = 116;
            // 
            // ThreeptmPlayer
            // 
            this.ThreeptmPlayer.Location = new System.Drawing.Point(256, 110);
            this.ThreeptmPlayer.Name = "ThreeptmPlayer";
            this.ThreeptmPlayer.Size = new System.Drawing.Size(100, 20);
            this.ThreeptmPlayer.TabIndex = 117;
            // 
            // FgaPlayer
            // 
            this.FgaPlayer.Location = new System.Drawing.Point(256, 62);
            this.FgaPlayer.Name = "FgaPlayer";
            this.FgaPlayer.Size = new System.Drawing.Size(100, 20);
            this.FgaPlayer.TabIndex = 118;
            // 
            // TovPlayer
            // 
            this.TovPlayer.Location = new System.Drawing.Point(256, 297);
            this.TovPlayer.Name = "TovPlayer";
            this.TovPlayer.Size = new System.Drawing.Size(100, 20);
            this.TovPlayer.TabIndex = 119;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(256, 333);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 95;
            this.button4.Text = "Edit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(256, 5);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(27, 13);
            this.label44.TabIndex = 95;
            this.label44.Text = "Fgm";
            this.label44.Click += new System.EventHandler(this.label44_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(256, 46);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(25, 13);
            this.label46.TabIndex = 120;
            this.label46.Text = "Fga";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(258, 94);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(52, 13);
            this.label47.TabIndex = 121;
            this.label47.Text = "Threeptm";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(258, 140);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(50, 13);
            this.label51.TabIndex = 122;
            this.label51.Text = "Threepta";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(256, 190);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(24, 13);
            this.label55.TabIndex = 123;
            this.label55.Text = "Ftm";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(259, 236);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(22, 13);
            this.label56.TabIndex = 124;
            this.label56.Text = "Fta";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(259, 281);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(26, 13);
            this.label57.TabIndex = 125;
            this.label57.Text = "Tov";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(359, 5);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(41, 13);
            this.label58.TabIndex = 126;
            this.label58.Text = "OffReb";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(359, 46);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(44, 13);
            this.label59.TabIndex = 127;
            this.label59.Text = "DefReb";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(359, 94);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(39, 13);
            this.label60.TabIndex = 128;
            this.label60.Text = "Assists";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(359, 140);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(32, 13);
            this.label61.TabIndex = 129;
            this.label61.Text = "Fouls";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(359, 190);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(36, 13);
            this.label62.TabIndex = 130;
            this.label62.Text = "Steals";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(364, 232);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(39, 13);
            this.label63.TabIndex = 131;
            this.label63.Text = "Blocks";
            // 
            // PlayerIdAdmin
            // 
            this.PlayerIdAdmin.Location = new System.Drawing.Point(362, 297);
            this.PlayerIdAdmin.Name = "PlayerIdAdmin";
            this.PlayerIdAdmin.Size = new System.Drawing.Size(100, 20);
            this.PlayerIdAdmin.TabIndex = 132;
            // 
            // Id
            // 
            this.Id.AutoSize = true;
            this.Id.Location = new System.Drawing.Point(364, 281);
            this.Id.Name = "Id";
            this.Id.Size = new System.Drawing.Size(16, 13);
            this.Id.TabIndex = 133;
            this.Id.Text = "Id";
            // 
            // Sponsor
            // 
            this.Sponsor.Location = new System.Drawing.Point(405, 28);
            this.Sponsor.Name = "Sponsor";
            this.Sponsor.Size = new System.Drawing.Size(100, 20);
            this.Sponsor.TabIndex = 31;
            this.Sponsor.TextChanged += new System.EventHandler(this.Sponsor_TextChanged);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(402, 12);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(46, 13);
            this.label64.TabIndex = 32;
            this.label64.Text = "Sponsor";
            // 
            // game_list_admin
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1285, 781);
            this.Controls.Add(this.Viewer);
            this.Name = "game_list_admin";
            this.Text = "game_list";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.Viewer.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox teams;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtWL;
        private System.Windows.Forms.TextBox txtConference;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox games_list;
        private System.Windows.Forms.Label Games;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCoach;
        private System.Windows.Forms.TextBox txtDivision;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListBox squad_list;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.RichTextBox statistics_players;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabControl Viewer;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.TextBox SearchTeam;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox PlayerName;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Edit;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.TextBox CoachEdit;
        private System.Windows.Forms.Label Coach;
        private System.Windows.Forms.ListBox player_list;
        private System.Windows.Forms.TextBox PlayerWeight;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox PlayerHeight;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox PlayerPosition;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox PlayerAge;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox PlayerId;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox CoachAge;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox CoachId;
        private System.Windows.Forms.Button DeleteCoach;
        private System.Windows.Forms.Button EditCoach;
        private System.Windows.Forms.Button AddCoach;
        private System.Windows.Forms.ListBox gamesListAdmin;
        private System.Windows.Forms.Button SearchGamesByTeam;
        private System.Windows.Forms.TextBox searchTeamAdmin;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox AwayTeamPoints;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox HomeTeamPoints;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox AwayTeamName;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox HomeTeamName;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox GameDate;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox ThreeptaHome;
        private System.Windows.Forms.TextBox ThreeptmHome;
        private System.Windows.Forms.TextBox FgaHome;
        private System.Windows.Forms.TextBox FgmHome;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox TovHome;
        private System.Windows.Forms.TextBox FoulsHome;
        private System.Windows.Forms.TextBox BlocksHome;
        private System.Windows.Forms.TextBox StealsHome;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox AssistsHome;
        private System.Windows.Forms.TextBox OffRebHome;
        private System.Windows.Forms.TextBox FtaHome;
        private System.Windows.Forms.TextBox FtmHome;
        private System.Windows.Forms.TextBox DefRebHome;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox GameId;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button edit_statistics_home;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox FgmAway;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox TovAway;
        private System.Windows.Forms.Label a;
        private System.Windows.Forms.TextBox FgaAway;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox BlocksAway;
        private System.Windows.Forms.Label aaa;
        private System.Windows.Forms.Label aa;
        private System.Windows.Forms.TextBox ThreeptmAway;
        private System.Windows.Forms.TextBox StealsAway;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox AssistsAway;
        private System.Windows.Forms.Label aaaaa;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox DefRebAway;
        private System.Windows.Forms.TextBox FoulsAway;
        private System.Windows.Forms.TextBox ThreeptaAway;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox OffRebAway;
        private System.Windows.Forms.TextBox FtmAway;
        private System.Windows.Forms.TextBox FtaAway;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.ListBox squadAdmin;
        private System.Windows.Forms.TextBox FgaPlayer;
        private System.Windows.Forms.TextBox ThreeptmPlayer;
        private System.Windows.Forms.TextBox ThreeptaPlayer;
        private System.Windows.Forms.TextBox OffRebPlayer;
        private System.Windows.Forms.TextBox DefRebPlayer;
        private System.Windows.Forms.TextBox AssistsPlayer;
        private System.Windows.Forms.TextBox FoulsPlayer;
        private System.Windows.Forms.TextBox StealsPlayer;
        private System.Windows.Forms.TextBox FtmPlayer;
        private System.Windows.Forms.TextBox FtaPlayer;
        private System.Windows.Forms.TextBox BlocksPlayer;
        private System.Windows.Forms.TextBox FgmPlayer;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox TovPlayer;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label Id;
        private System.Windows.Forms.TextBox PlayerIdAdmin;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox Sponsor;
    }
}

